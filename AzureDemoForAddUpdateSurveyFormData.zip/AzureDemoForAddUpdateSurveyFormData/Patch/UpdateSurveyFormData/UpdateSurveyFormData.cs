using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NuveenAddUpdateSurveyFormData.Model;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.OpenApi.Models;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;

namespace NuveenAddUpdateSurveyFormData
{
    public static class UpdateSurveyFormData
    {
        [OpenApiOperation(operationId: "UpdateSurveyFormData", tags: new[] { "PATCH" }, Summary = "Updates survey form data.", Description = "Updates survey form data.", Visibility = OpenApiVisibilityType.Important)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SurveyFormData), Required = true, Description = "Survey form data (JSON)")]
        [OpenApiParameter(name: "language", In = ParameterLocation.Query, Required = false, Type = typeof(string), Summary = "Survey language value", Description = "Survey language value", Visibility = OpenApiVisibilityType.Important)]
        [OpenApiParameter(name: "itemid", In = ParameterLocation.Query, Required = false, Type = typeof(string), Summary = "Sitecore item ID.", Description = "Sitecore item ID.", Visibility = OpenApiVisibilityType.Important)]
        [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "code", In = OpenApiSecurityLocationType.Query)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string), Summary = "The response", Description = "This returns the `200 - OK` response")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.Unauthorized, contentType: "plain/text", bodyType: typeof(string), Summary = "The response", Description = "This returns the `401 - Unauthorized` response")]
        [FunctionName("UpdateSurveyFormData")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Function, "patch", Route = null)] HttpRequest req,
            ILogger log)
        {

            try
            {
                string itemid = req.Query["itemid"];

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var surveydata = JsonConvert.DeserializeObject<SurveyFormData>(requestBody);
                itemid = itemid ?? surveydata?.ItemID;
                //call authentication
                if (surveydata != null)
                {
                    var env = Environment.GetEnvironmentVariables();

                    #region Authentication

                    var authUrl = string.Concat(env["Host"].ToString(), env["ItemServiceAuthUrl"]);

                    log.LogInformation($"authUrl: {authUrl}");
                    log.LogInformation($"Domain: {env["Domain"]}");
                    log.LogInformation($"Sitecoreusername: {env["Sitecoreusername"]}");

                    var authData = new Authentication
                    {
                        Domain = env["Domain"].ToString(),
                        Username = env["Sitecoreusername"].ToString(),
                        Password = env["Password"].ToString()
                    };

                    var authRequest = (HttpWebRequest)WebRequest.Create(authUrl);
                    authRequest.Method = "POST";
                    authRequest.ContentType = "application/json";
                    var requestAuthBody = JsonConvert.SerializeObject(authData);
                    var authDatas = new UTF8Encoding().GetBytes(requestAuthBody);

                    using (var dataStream = authRequest.GetRequestStream())
                    {
                        dataStream.Write(authDatas, 0, authDatas.Length);
                    }

                    CookieContainer cookies = new CookieContainer();
                    authRequest.CookieContainer = cookies;
                    var authResponse = authRequest.GetResponse();
                    log.LogInformation($"Login Status:\n\r{((HttpWebResponse)authResponse).StatusDescription}");
                    authResponse.Close();

                    #endregion

                    var updateurl = string.Concat(env["Host"].ToString(), env["ItemServiceUpdateUrl"]);
                    updateurl = updateurl.Replace("{lang}", surveydata.Language).Replace("{itemid}", itemid);

                    var response = Helper.Functions.GetApiResponse(updateurl, cookies, surveydata, log, "PATCH");

                    //	'204 - No Content' expected from Sitecore Item Web API. This is the response when the request is successful.
                    if (response != null && response.StatusCode == HttpStatusCode.NoContent)
                    {
                        // Return success state; 200 (OK); PATCH sucessfully executed.
                        var jsonString = $"{{ \"status\": \"success\", \"id\": \"{itemid}\"}}";
                        HttpResponseMessage httpResponseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                        {
                            Content = new StringContent(jsonString, Encoding.UTF8, "application/json")
                        };
                        return httpResponseMessage;
                    }
                    else
                    {
                        // Return failed state; '400 (Bad Request) / 403 (Forbidden) /404 (Not Found)'; dependent on response from the item service.
                        HttpResponseMessage unexpectedStatusCodeResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                        {
                            Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"The response's status returned an unexpected code: {response?.StatusCode}.\"}}", Encoding.UTF8, "application/json")
                        };
                        return unexpectedStatusCodeResponse;
                    }
                }
                else
                {
                    // Return failed state; '400 - Bad Request; survey data missing from body.
                    HttpResponseMessage unexpectedDataInputResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
                    {
                        Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"The request contained unexpected data.\"}}", Encoding.UTF8, "application/json")
                    };
                    return unexpectedDataInputResponse;
                }


            }
            catch (Exception ex)
            {
                log.LogInformation($"UpdateSurveyFormData -error: {ex.ToString()} ");

                // Return failed state; '500 - Internal Server Error
                HttpResponseMessage invalidInputResponseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"{ex.Message}\"}}", Encoding.UTF8, "application/json")
                };
                return invalidInputResponseMessage;
            }
        }
    }
}
