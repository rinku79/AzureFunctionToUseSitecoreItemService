﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace NuveenAddUpdateSurveyFormData.Model
{
	public partial class SurveyFormData
    {
        [JsonProperty("Language")] 
        public string Language { get; set; } = "en";

		[JsonProperty("TemplateID")]
		public  string TemplateID { get=> Environment.GetEnvironmentVariable("SurveyFormDataTemplateID"); }

        [JsonProperty("ItemID")]
        public string ItemID { get; set; }
       
        [JsonProperty("ItemName")]
        public string ItemName { get; set; }
		
        [JsonProperty("IsCompleted")] 
        public string IsCompleted { get; set; } = "0";

        [JsonProperty("Survey Input Json")]
		public  string SurveyInputJson { get; set; }

        [JsonProperty("Survey Result Json")]
		public  string SurveyResultJson { get; set; }

        [JsonProperty("Time Statistics Json")]
		public  string TimeStatisticsJson { get; set; }

        [JsonProperty("Completion Date")]
		public string CompletionDate { get; set; }

        [JsonProperty("Current Panel Count")]
		public  string CurrentPanelCount { get; set; }
      
        [JsonProperty("Session ID")]
		public string SessionID { get; set; }

        [JsonProperty("Start Date")]
		public  string StartDate { get; set; }

        [JsonProperty("Survey Form ID")]
		public  string SurveyFormID { get; set; }

        [JsonProperty("Survey Name")]
		public  string SurveyName { get; set; }

        [JsonProperty("Survey Type")]
		public  string SurveyType { get; set; }

        [JsonProperty("Total Survey Time")]
		public  string TotalSurveyTime { get; set; }

        [JsonProperty("User Email")]
		public  string UserEmail { get; set; }
	}
}
