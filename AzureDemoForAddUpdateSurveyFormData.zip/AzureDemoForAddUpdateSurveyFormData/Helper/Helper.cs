﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NuveenAddUpdateSurveyFormData.Model;

namespace NuveenAddUpdateSurveyFormData.Helper
{
    static class  Functions
    {
        public static HttpWebResponse GetApiResponse(string apiUrl, CookieContainer cookies, object surveydata, ILogger log, string requestType="POST")
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(apiUrl);
                request.Method = requestType;
                request.ContentType = "application/json";
                request.CookieContainer = cookies;
                if (surveydata != null)
                {
                    JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
                        {NullValueHandling = NullValueHandling.Ignore};
                    var requestBody = JsonConvert.SerializeObject(surveydata, jsonSerializerSettings);

                    var data = new UTF8Encoding().GetBytes(requestBody);

                    using (var dataStream = request.GetRequestStream())
                    {
                        dataStream.Write(data, 0, data.Length);
                    }
                }

                var response =(HttpWebResponse) request.GetResponse();
                return response;
            }

            catch (Exception ex)
            {
                log.LogError($"Functions-GetApiResponse: Error in execution: {apiUrl}, Error: {ex.ToString()}");
            }
            return null;
        }
        public static string GetApiAsync(string apiUrl, ILogger log)
        {
            try
            {
                HttpClient _httpClient = new HttpClient();
                string apiResponse = string.Empty;
                apiResponse = _httpClient.GetStringAsync(apiUrl).Result;
                return apiResponse;
            }
            catch (Exception ex)
            {
                log.LogError($"Functions-GetApiAsync: Error in execution: {apiUrl}, Error: {ex.ToString()}");
            }
            return null;
        }

        // TODO: No longer referenced or needed.  Can be removed. 
        public static string SearchSurveyItem(SurveyFormData surveydata, CookieContainer cookies, ILogger log)
        {
            try
            {
                var env = Environment.GetEnvironmentVariables();
                var searchurl = string.Concat(env["Host"].ToString(), env["ItemServiceSearchUrl"]);
                searchurl = searchurl.Replace("{lang}", surveydata.Language);
                searchurl = searchurl.Replace("{SEARCHTERM}", surveydata.SessionID);
                
                log.LogInformation($"Executing search for item to: {searchurl}");
                var response = Helper.Functions.GetApiResponse(searchurl, cookies, null, log, "GET");
                if (response != null)
                {
                    string responseBody =  new StreamReader(response.GetResponseStream()).ReadToEnd();
                    dynamic data = JsonConvert.DeserializeObject(responseBody);
                    var TotalCount = data?.TotalCount;
                    var Result = ((JArray)data?.Results)?[0];
                    var searcheditemid = Result?.SelectToken("ItemID").ToString();
                    return searcheditemid;
                }
                else
                {
                    log.LogError($"Response is null.");
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Functions-SearchSurveyItem: Error in execution, sessionid: {surveydata.SessionID}, Error: {ex.ToString()}");
            }
            return null;
        }
    }
}
