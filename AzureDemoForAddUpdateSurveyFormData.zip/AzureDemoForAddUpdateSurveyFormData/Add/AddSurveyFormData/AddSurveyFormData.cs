using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NuveenAddUpdateSurveyFormData.Model;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.OpenApi.Models;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using System.Text.RegularExpressions;

namespace NuveenAddUpdateSurveyFormData
{
    public static class AddSurveyFormData
    {
        [OpenApiOperation(operationId: "AddSurveyFormData", tags: new[] { "POST" }, Summary = "Add survey form data.", Description = "Adds survey form data.", Visibility = OpenApiVisibilityType.Important)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SurveyFormData), Required = true, Description = "Survey form data (JSON)")]
        [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "code", In = OpenApiSecurityLocationType.Query)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(string), Summary = "The response", Description = "This returns the `200 - OK` response")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.Unauthorized, contentType: "plain/text", bodyType: typeof(string), Summary = "The response", Description = "This returns the `401 - Unauthorized` response")]
        [FunctionName("AddSurveyFormData")]
        public static async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var surveydata = JsonConvert.DeserializeObject<SurveyFormData>(requestBody);

                // Get environment variables either from local.settings.json or Azure Functions Configuration.
                var env = Environment.GetEnvironmentVariables();

                #region Authentication

                var authUrl = string.Concat(env["Host"].ToString(), env["ItemServiceAuthUrl"]);

                log.LogInformation($"authUrl: {authUrl}");
                log.LogInformation($"Domain: {env["Domain"]}");
                log.LogInformation($"Sitecoreusername: {env["Sitecoreusername"]}");

                var authData = new Authentication
                {
                    Domain = env["Domain"].ToString(),
                    Username = env["Sitecoreusername"].ToString(),
                    Password = env["Password"].ToString()
                };

                var authRequest = (HttpWebRequest)WebRequest.Create(authUrl);
                authRequest.Method = "POST";
                authRequest.ContentType = "application/json";
                var requestAuthBody = JsonConvert.SerializeObject(authData);
                var authDatas = new UTF8Encoding().GetBytes(requestAuthBody);

                using (var dataStream = authRequest.GetRequestStream())
                {
                    dataStream.Write(authDatas, 0, authDatas.Length);
                }

                CookieContainer cookies = new CookieContainer();
                authRequest.CookieContainer = cookies;

                log.LogInformation($"Requesting authorization from Sitecore.");
                var authResponse = authRequest.GetResponse();
                log.LogInformation($"Login Status:\n\r{((HttpWebResponse)authResponse).StatusDescription}");
                authResponse.Close();

                #endregion

                //call sitecore itemservice to create item and return its path
                if (surveydata != null)
                {
                    var createurl = string.Concat(env["Host"].ToString(), env["ItemServiceCreateUrl"]);
                    createurl = createurl.Replace("{lang}", surveydata.Language);
                    log.LogInformation($"Calling Sitecore Item API URL: {createurl}");

                    var response = Helper.Functions.GetApiResponse(createurl, cookies, surveydata, log);
                    //	'201 - Created' expected from Sitecore Item Web API. This is the response when the request is successful.
                    if (response !=null && response.StatusCode == HttpStatusCode.Created)
                    {
                        // Get the item ID for the newly created item from the Header > Location in the response. Match with a regular expression and extract the ID.
                        var responseLocationHeader = response.Headers.GetValues("Location")[0];
                        var regex = new Regex(@"\/item\/(.*)\?");
                        var match = regex.Match(responseLocationHeader);
                        var surveyItemId = match.Groups[1].Value;
                        log.LogInformation($"Item created sucessfully: {surveyItemId}");

                        // Return success state; 200 (OK); POST sucessfully executed.
                        var jsonString = $"{{ \"status\": \"success\", \"id\": \"{surveyItemId}\"}}";
                        HttpResponseMessage httpResponseMessage = new HttpResponseMessage(HttpStatusCode.OK)
                        {
                            Content = new StringContent(jsonString, Encoding.UTF8, "application/json")
                        };
                        return httpResponseMessage;
                    }
                    else
                    {
                        // Return failed state; '400 (Bad Request) / 403 (Forbidden) /404 (Not Found)' dependent on response from the item service.
                        HttpResponseMessage unexpectedStatusCodeResponse = new HttpResponseMessage(response.StatusCode)
                        {
                            Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"The response's status returned an unexpected code: {response?.StatusCode}.\"}}", Encoding.UTF8, "application/json")
                        };
                        return unexpectedStatusCodeResponse;
                    }
                }
                else
                {
                    // Return failed state; '400 - Bad Request; survey data missing from body.
                    HttpResponseMessage unexpectedDataInputResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
                    {
                        Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"The request contained unexpected data.\"}}", Encoding.UTF8, "application/json")
                    };
                    return unexpectedDataInputResponse;
                }
            }
            catch (Exception ex)
            {
                log.LogInformation($"AddSurveyFormData -error: {ex.ToString()} ");

                // Return failed state; '500 - Internal Server Error
                HttpResponseMessage invalidInputResponseMessage = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent($"{{ \"status\": \"failed\", \"message\": \"{ex.Message}\"}}", Encoding.UTF8, "application/json")
                };
                return invalidInputResponseMessage;
            }
        }
    }
}